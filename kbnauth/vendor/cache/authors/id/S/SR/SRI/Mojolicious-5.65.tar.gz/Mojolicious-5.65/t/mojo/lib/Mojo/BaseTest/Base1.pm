package Mojo::BaseTest::Base1;
use Mojo::Base -base;

has 'bananas';

1;
